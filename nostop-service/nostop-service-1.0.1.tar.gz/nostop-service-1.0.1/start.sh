#!/bin/sh

# Adding /run/current-system/sw/bin to PATH for NixOS support
PATH=$PATH:/run/current-system/sw/bin

echo nostop-service started

trap '' INT TERM
sleep 1d

