#!/bin/sh

# Adding /run/current-system/sw/bin to PATH for NixOS support
PATH=$PATH:/run/current-system/sw/bin

echo nostop-service started

trap -- '' SIGINT SIGTERM
sleep 1d

