#!/bin/sh

PATH=$PATH:/run/current-system/sw/bin

echo test-service started

sleep 1d
