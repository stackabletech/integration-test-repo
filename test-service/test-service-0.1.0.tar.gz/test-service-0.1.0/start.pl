#!/usr/bin/env perl

use strict;
use warnings;

print "test-service started\n";

sleep 3;
