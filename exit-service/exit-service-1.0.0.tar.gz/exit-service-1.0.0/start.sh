#!/bin/sh

# Adding /run/current-system/sw/bin to PATH for NixOS support
# PATH=$PATH:/run/current-system/sw/bin

exit $EXIT_CODE
