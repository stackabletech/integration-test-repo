#!/bin/sh

exit ${EXIT_CODE:-0}
