#!/bin/sh

exit $EXIT_CODE
